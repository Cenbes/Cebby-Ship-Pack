# Cebby-Ship-Pack
A probably OP ships made for fun by me into Starsector.
This mod now adds 2 High-tech ships and 2 rare ships you can find via exploring.
